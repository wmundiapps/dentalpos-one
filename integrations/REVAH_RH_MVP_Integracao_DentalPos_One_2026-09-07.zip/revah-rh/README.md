# REVAH RH

MVP técnico independente de RH, ponto digital, pré-folha, folha e integração com DentalPos One.

## Incluído
- multiempresa;
- funcionários;
- terminal de ponto desktop-only;
- dispositivo autorizado;
- estrutura biométrica WebAuthn/Windows Hello ou SDK;
- NSR + hash de recibo;
- justificativas e upload de atestado;
- triagem técnica de documentos;
- eventos de pré-folha (provento/desconto/informação);
- fechamento do contador;
- aprovação do gestor;
- estrutura para lote bancário;
- alertas e auditoria;
- integração DentalPos por webhook/HMAC.

## Fluxo
RH alimenta → contador fecha → gestor confere/aprova → banco.

## Subir local
```bash
docker compose up -d postgres
cp .env.example .env
npm install
npm run prisma:generate
npm run db:push:dev
npm run seed
npm run dev
```

Painel: http://localhost:8787
Terminal: http://localhost:8787/kiosk

`db:push:dev` é apenas para o banco NOVO do REVAH RH. Nunca usar no banco do DentalPos One.
