import { Router } from 'express'
import { z } from 'zod'
import { desktopOnly } from '../middleware/desktopOnly.js'
import { deviceAuth } from '../middleware/deviceAuth.js'
import { createPunch } from '../services/attendanceEngine.js'
import { prisma } from '../db.js'
export const timeClockRouter=Router();const P=z.object({employeeCode:z.string().min(1),type:z.enum(['IN','BREAK_OUT','BREAK_IN','OUT']),biometricVerified:z.literal(true),method:z.enum(['WEBAUTHN','BIOMETRIC_SDK']).default('WEBAUTHN')});timeClockRouter.post('/punch',desktopOnly,deviceAuth,async(req,res)=>{const p=P.safeParse(req.body);if(!p.success)return res.status(400).json({error:p.error.flatten()});const device=(req as any).revahDevice;const employee=await prisma.employee.findFirst({where:{organizationId:device.organizationId,employeeCode:p.data.employeeCode,active:true}});if(!employee)return res.status(404).json({error:'EMPLOYEE_NOT_FOUND'});const punch=await createPunch({organizationId:device.organizationId,employeeId:employee.id,deviceId:device.id,type:p.data.type,method:p.data.method,sourceIp:req.ip,userAgent:String(req.headers['user-agent']||'')});res.status(201).json({ok:true,employee:employee.fullName,occurredAt:punch.occurredAt,nsr:punch.nsr,receiptHash:punch.receiptHash})});
