import { Router } from 'express'
import crypto from 'node:crypto'
import { prisma } from '../db.js'
export const devicesRouter=Router();devicesRouter.post('/register',async(req,res)=>{const {organizationId,name,hostname,operatingSystem,location}=req.body||{};if(!organizationId||!name)return res.status(400).json({error:'organizationId e name obrigatórios'});const deviceKey=crypto.randomBytes(32).toString('hex');const device=await prisma.timeClockDevice.create({data:{organizationId,name,hostname,operatingSystem,location,deviceKey,desktopOnly:true}});res.status(201).json({...device,warning:'Guarde a deviceKey somente no desktop autorizado.'})});
