import type { Request,Response,NextFunction } from 'express'
import { prisma } from '../db.js'
export async function deviceAuth(req:Request,res:Response,next:NextFunction){const deviceKey=String(req.headers['x-revah-device-key']||'');if(!deviceKey)return res.status(401).json({error:'DEVICE_KEY_REQUIRED'});const device=await prisma.timeClockDevice.findUnique({where:{deviceKey}});if(!device||!device.active)return res.status(403).json({error:'DEVICE_NOT_AUTHORIZED'});(req as any).revahDevice=device;await prisma.timeClockDevice.update({where:{id:device.id},data:{lastSeenAt:new Date()}});next()}
