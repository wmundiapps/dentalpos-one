import type { Request,Response,NextFunction } from 'express'
const MOBILE=/Android|iPhone|iPad|iPod|Mobile|Windows Phone/i
export function desktopOnly(req:Request,res:Response,next:NextFunction){const ua=String(req.headers['user-agent']||'');if(MOBILE.test(ua))return res.status(403).json({error:'PONTO_DESKTOP_ONLY',message:'O registro de ponto REVAH RH só pode ser realizado em terminal desktop autorizado.'});next()}
