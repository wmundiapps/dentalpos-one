# Conformidade Brasil

## Ponto eletrônico
Arquitetura desenhada para evoluir para REP-P: coletor desktop, identificação, sequência de registros, auditoria, recibo/hash e programa de tratamento. Antes de uso oficial, validar aderência integral à Portaria MTP 671/2021 vigente.

## Biometria
Biometria é dado pessoal sensível. Preferir WebAuthn/Windows Hello, mantendo biometria no dispositivo/autenticador, sem armazenar imagem/template facial no servidor. O ponto deve ser bloqueado em celular.

## Atestados
A triagem automática pode detectar arquivo vazio, ilegível, duplicado ou tecnicamente inconsistente. Não deve declarar autonomamente que documento é falso; fraude exige revisão humana e validação apropriada.

## Folha/eSocial
Pré-folha e fechamento podem ser preparados no REVAH RH; transmissão oficial, assinatura, cálculo tributário e guias dependem de conector/contador e regras vigentes.

## Pagamentos
RH alimenta → contador fecha → gestor aprova → lote bancário. Nenhuma transferência real sem aprovação e conector bancário configurado.
