# REVAH RH — Escopo integrado

## 1. Pessoas e vínculos
Cadastro multiempresa de colaboradores, cargo, setor, jornada, salário-base, dados bancários, documentos, férias e histórico.

## 2. Ponto digital
Terminal somente desktop cadastrado; biometria via Windows Hello/WebAuthn ou SDK homologado; entrada, saída, intervalos, NSR, recibo/hash, auditoria e programa de tratamento de ponto.

## 3. Jornada e exceções
Escala, atrasos, faltas, horas extras, banco de horas, assiduidade, adicional/insalubridade e pendências para revisão humana.

## 4. Justificativas e atestados
Upload de PDF/foto; hash; duplicidade; arquivo vazio/ilegível; triagem por IA; fila de revisão; jamais acusação automática de falsidade.

## 5. Disciplina
Rascunho de advertência por falta/atraso injustificado; justificativa antes da decisão; aprovação humana; ciência do colaborador e histórico.

## 6. Pré-folha
Vales, prêmios, perda de prêmio, descontos, faltas, horas extras, adicionais, comissões e eventos configuráveis.

## 7. Folha e contador
RH alimenta → contador revisa/fecha → gestor aprova. Competência mensal, trilha de alterações e exportação/conector contábil.

## 8. Bancos e conta-salário
Dados bancários do funcionário; lote salarial; dupla etapa de aprovação; interface de provedor bancário. Produção depende da API/contrato do banco escolhido.

## 9. Fiscal, trabalhista e contábil
Camada de integração para eSocial, rubricas, remuneração/pagamentos, encargos, FGTS/INSS/IRRF e guias. Cálculo/transmissão oficial ficam condicionados aos leiautes vigentes, certificado/assinatura e conector homologado.

## 10. Inteligência gerencial
Indicadores de jornada, absenteísmo, atrasos, horas extras, custo de folha, custo por setor, previsão de desembolso e alertas de inconsistência.

## 11. REVAH comunicações
Avisos internos ao gestor/RH/contador por eventos, sem expor dados além do necessário. Pode usar o motor de mensagens REVAH para alertas operacionais autorizados.

## 12. DentalPos One
Sincronização por eventos assinados, reaproveitando os modelos de RH existentes no DentalPos One. Sem banco paralelo dentro do DentalPos e sem transmitir biometria bruta.
