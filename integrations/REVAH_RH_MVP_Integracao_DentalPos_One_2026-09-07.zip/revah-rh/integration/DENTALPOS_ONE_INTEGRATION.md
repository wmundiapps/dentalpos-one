# REVAH RH ↔ DentalPos One

O REVAH RH funciona independente. O DentalPos One deve consumir apenas eventos autorizados.

A base atual do DentalPos One já possui modelos `HREmployee`, `HRAttendance`, `HRPayrollEntry`, `HRPayrollClosing`, `HRVacation`, `HRDocument` e `HRDisciplinaryAction`. O mapeamento deve reutilizar esses modelos, sem criar RH paralelo.

## Eventos
- RevahRH.EmployeeUpdated
- RevahRH.TimePunchCreated
- RevahRH.AttendanceExceptionCreated
- RevahRH.JustificationSubmitted
- RevahRH.PayrollPeriodReady
- RevahRH.PayrollManagerApproved
- RevahRH.BankBatchSubmitted

## Segurança
HMAC SHA-256, idempotência, tenant/clinic obrigatórios, auditoria e nenhum dado biométrico bruto enviado ao DentalPos.

## Mapeamento
Employee → HREmployee
TimePunch → HRAttendance
PayrollEvent → HRPayrollEntry
PayrollPeriod → HRPayrollClosing
EmployeeDocument → HRDocument
DisciplinaryAction → HRDisciplinaryAction

Não executar `prisma migrate dev`, reset ou deploy no DentalPos durante a integração.
